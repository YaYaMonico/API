package com.api.yasminmonico.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.api.yasminmonico.models.Mensagem;
import com.api.yasminmonico.service.ServiceMensagem;

@RestController 
@RequestMapping("/api/teste")

public class ControllerMensagem {

	
}
